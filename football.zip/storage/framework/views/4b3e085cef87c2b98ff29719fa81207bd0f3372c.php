<?php $__env->startSection('role','active'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container pt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Role Edit Page
                </div>
                <form action="<?php echo e(route('roles.update',$role->id)); ?>" method="POST" id="role-edit">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($role->name); ?>">
                        </div>

                        <div class="row">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="form-check mb-3">
                                    <input type="checkbox" class="form-check-input" value="<?php echo e($permission->name); ?>" name="permissions[]" 
                                    id="name_<?php echo e($permission->id); ?>" <?php if(in_array($permission->name,$old_permissions)): ?> checked <?php endif; ?>>
                                    <label class="form-check-label" for="name_<?php echo e($permission->id); ?>"  ><?php echo e($permission->name); ?></label>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-theme" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\PermissionEdit', '#role-edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/backend/roles/edit.blade.php ENDPATH**/ ?>