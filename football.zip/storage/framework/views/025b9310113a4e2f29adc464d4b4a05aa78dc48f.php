<?php $__env->startSection('display','d-none d-md-block'); ?>

<?php $__env->startSection('content'); ?>
<div class="web-sidebar-widget">
    <div class="widget-head">
        <div class="d-flex justify-content-between">
            <h3>ငွေစာရင်းအသေးစိတ်</h3>
        </div>
    </div>
    <div class="widget-body">
        <div class="d-flex justify-content-between align-items-center">
            <p><strong>ရက်စွဲ</strong></p>
            <p><strong>အကြောင်းအရာ</strong></p>
            <p><strong>ငွေပမာဏ</strong></p>
        </div>
        <?php $__currentLoopData = $htote_ngwe_detail ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <p class="mb-1"><strong><?php echo e($detail->updated_at->format('d-m-Y')); ?></strong></p>
                <p><strong><?php echo e($detail->updated_at->format('h:i:s A')); ?></strong></p>
            </div>
            <p style="padding-right : 52px"><strong>To Agent</strong></p>
            <p style="padding-right : 17px"><strong><?php echo e($detail->amount); ?></strong></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/frontend/htote_ngwe_history_detail.blade.php ENDPATH**/ ?>