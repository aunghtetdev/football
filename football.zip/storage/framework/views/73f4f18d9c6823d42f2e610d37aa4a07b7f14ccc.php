<?php echo $__env->make('frontend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('display','d-none d-md-block'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <div class="row">
            <span class=" pl-3" style="font-weight: 900">လောင်းထားသောပွဲများ</span>
        </div>
    </div>
    <?php echo $__env->make('frontend.bets.bet-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$( function() {
    $( "#datepicker" ).datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function(date) {
            $("#filter-form").submit();
            //OR $("#yourButton").click();
        }
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/frontend/bets/active-bet.blade.php ENDPATH**/ ?>