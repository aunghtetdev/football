<?php $__env->startSection('match','active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Match Edit Page
                </div>
                <form action="<?php echo e(route('matches.update',$match->id)); ?>" method="POST" id="match-edit">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <div class="label">Home Team</div>
                            <select name="home_team_id" class="form-control select2">
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>" <?php echo e($match->home_team_id == $team->id  ? 'selected' : ''); ?>><?php echo e($team->name_mm); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="label">Home Team Goal</div>
                            <input type="number" class="form-control" value="<?php echo e($match->home_team_goal); ?>" name="home_team_goal">
                        </div>
                        <div class="form-group">
                            <div class="label">Away Team</div>
                            <select name="away_team_id" class="form-control select-role">
                                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>" <?php echo e($match->away_team_id == $team->id ? "selected" : ""); ?>><?php echo e($team->name_mm); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="label">Away Team Goal</div>
                            <input type="number" class="form-control" value="<?php echo e($match->away_team_goal); ?>" name="away_team_goal">
                        </div>
                        <div class="form-group">
                            <div class="label">Match Date</div>
                            <input type="text" class="form-control" id="daterangepicker" value="<?php echo e(Carbon\Carbon::parse($match->date)->format('Y-m-d H:i:s')); ?>" name="date">
                        </div>
                        <div class="form-group">
                            <div class="label">Match Finished</div>
                            <select name="finished" class="form-control select-role">
                                <option value="1" <?php echo e($match->finished == 1 ? "selected" : ""); ?>>Yes</option>
                                <option value="0" <?php echo e($match->finished == 0 ? "selected" : ""); ?>>No</option>
                            </select>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-theme" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\MatchUpdate', '#match-edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/backend/matches/edit.blade.php ENDPATH**/ ?>