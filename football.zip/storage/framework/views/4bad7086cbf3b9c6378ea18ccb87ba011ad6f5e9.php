<?php $__env->startSection('team','active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Team Create Page
                </div>
                <form action="<?php echo e(route('teams.store')); ?>" method="POST" id="team-create" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">League</label>
                            <select name="league_id" class="form-control" id="">
                                <option value="">Select League</option>
                                <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($league->id); ?>"><?php echo e($league->name_mm); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Name (MM)</label>
                            <input type="text" class="form-control" name="name_mm">
                        </div>
                        
                        

                        
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-primary" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\TeamCreate', '#team-create'); ?>

<script>
    $(document).ready(function(){
        $('#team_image').on('change',function(event){
            var file_length = document.getElementById('team_image').files.length;
            $('.preview-img').html('');
            for(var i=0; file_length > i ;i++){
                $('.preview-img').append(`<img src=${URL.createObjectURL(event.target.files[i])} style="width: 50px; border-radius:5px;" />`)
            }
        })
    })
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/backend/teams/create.blade.php ENDPATH**/ ?>