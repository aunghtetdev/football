<?php $__env->startSection('wallet','active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <?php echo $__env->make('backend.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Balance Add Page
                </div>
                <form action="<?php echo e(url('admin/wallets/'.$wallet->id.'/store')); ?>" method="POST" id="wallet-add">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Username</label>
                            <input type="text" class="form-control" value="<?php echo e($wallet->user ? $wallet->user->username : '-'); ?>">
                            <input type="hidden" name="user_id" value="<?php echo e($wallet->user_id); ?>">
                        </div>
    
                        <div class="form-group">
                            <label for="">Amount</label>
                            <input type="text" class="form-control" name="amount">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-theme" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\WalletAdd', '#wallet-add'); ?>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/backend/wallets/add.blade.php ENDPATH**/ ?>