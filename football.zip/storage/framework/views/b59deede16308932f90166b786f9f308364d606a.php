<?php $__env->startSection('title', 'Home'); ?>
<?php echo $__env->make('frontend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('display','d-none d-md-block'); ?>

<?php $__env->startSection('content'); ?>
<section>
    <div class="game-box">
        <div class="card">
            <div class="card-body">
                <div class="match_today container" id="match_today">
                    <form action="<?php echo e(route('match.bet-match')); ?>" id="bet-form" method="POST">
                    <?php echo csrf_field(); ?>
                    <h3>ဘော်ဒီပွဲစဥ်များ</h3>
                    <!--matches-->
                    <?php $__currentLoopData = $matches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="match-content" id="match-content-<?php echo e($match->odd_id); ?>">
                        
                        <div class="match-content-inner">
                            <span class="match-date">06 Feb</span>
                            <div class="mpart1">
                                <div class="right_match">
                                    <span class="right_tech">
                                        <img src="<?php echo e(asset('image/football.png')); ?>">
                                        <?php if($match->away_team_id == $match->underteam_id): ?>
                                        <div class="fname"><?php echo e($match->away_team_name); ?></div>
                                        <?php elseif($match->home_team_id == $match->underteam_id): ?>
                                        <div class="fname"><?php echo e($match->home_team_name); ?>(H)</div>
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <strong class="match-time"><?php echo e($match->match_time); ?></strong>
                                <div class="left_match">
                                    <span class="left_tech">
                                        <img src="<?php echo e(asset('image/football.png')); ?>">
                                        <?php if($match->home_team_id == $match->over_team_id): ?>
                                        <div class="fname"><?php echo e($match->home_team_name); ?>(H)</div>
                                        <?php elseif($match->away_team_id == $match->over_team_id): ?>
                                        <div class="fname"><?php echo e($match->away_team_name); ?></div>
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                            <div class="bet-match">
                                <span>
                                    <input type="radio" id="over-team-<?php echo e($match->odd_id); ?>" value="<?php echo e($match->over_team_id); ?>-<?php echo e($match->id); ?>-<?php echo e($match->match_id); ?>-<?php echo e($match->over_team_id); ?>-<?php echo e($match->underteam_id); ?>-<?php echo e($match->match_time); ?>" name="bet">
                                    <label for="over-team-<?php echo e($match->odd_id); ?>" class="over-team"> အပေါ်ကြေးအသင်း (<?php echo e($match->body_value); ?>)</label>
                                </span>
                                <span>
                                    <input type="radio" id="under-team-<?php echo e($match->odd_id); ?>" value="<?php echo e($match->underteam_id); ?>-<?php echo e($match->id); ?>-<?php echo e($match->match_id); ?>-<?php echo e($match->over_team_id); ?>-<?php echo e($match->underteam_id); ?>-<?php echo e($match->match_time); ?>" name="bet">
                                    <label for="under-team-<?php echo e($match->odd_id); ?>" class="under-team">အောက်ကြေးအသင်း</label>
                                </span>
                                <span class="over">
                                    <input type="radio" id="over-goal-<?php echo e($match->odd_id); ?>" value="over-<?php echo e($match->id); ?>-<?php echo e($match->match_id); ?>-<?php echo e($match->over_team_id); ?>-<?php echo e($match->underteam_id); ?>-<?php echo e($match->match_time); ?>" name="bet">
                                    <label for="over-goal-<?php echo e($match->odd_id); ?>">ဂိုးပေါ် (<?php echo e($match->goal_total_value); ?>)</label>
                                </span>
                                <span class="under">
                                    <input type="radio" id="under-goal-<?php echo e($match->odd_id); ?>" value="under-<?php echo e($match->id); ?>-<?php echo e($match->match_id); ?>-<?php echo e($match->over_team_id); ?>-<?php echo e($match->underteam_id); ?>-<?php echo e($match->match_time); ?>" name="bet">
                                    <label for="under-goal-<?php echo e($match->odd_id); ?>" class="under-goal">ဂိုးအောက်</label>
                                </span>
                                
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="bet-submit">
                        <input type="text" class="bet-submit-amount" name="bet_amount" placeholder="လောင်းကြေး...">
                        <input type="submit" onclick="betSubmit(event)" value="Bet" class="btn btn-primary bet-submit-btn">
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>
        
    //Submit Bet with confirm box
    function betSubmit(event) {
        event.preventDefault();
        var bet = $("input[name=bet]:checked").val();
        var bet_amount = $("input[name=bet_amount]").val();
        var amount = <?php echo json_encode((array)auth()->user()->wallet->amount); ?>;
        console.log(amount)
        if(!bet)
        {
            Toast.fire({
                icon: 'info',
                title: 'လောင်းမည့်အသင်းရွေးပေးပါ။'
            })
        }else if(bet_amount < 1000){
            Toast.fire({
                icon: 'info',
                title: 'အနည်းဆုံး ၁၀၀၀ကျပ် လောင်းပါ။'
            })
        }else if(amount < bet_amount){
            Toast.fire({
                icon: 'info',
                title: 'လက်ကျန်ငွေမလုံလောက်ပါ။'
            })
        }else{
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success ml-1',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false
                })
                swalWithBootstrapButtons.fire({
                title: 'လောင်းမည်',
                text: 'လောင်းမည်သေချာပါသလား!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'သေချာသည်',
                cancelButtonText: 'မသေချာပါ',
                reverseButtons: true
                }).then((result) => {
                if (result.isConfirmed) {
                    var match_time = bet.split('-')[5];
                    var current_time = formatAMPM(new Date);
                    console.log(current_time)
                    if(match_time < current_time)
                    {
                        Toast.fire({
                        icon: 'error',
                        title: 'ပွဲစသွားပါပြီ။'
                        })
                        location.reload();
                    }else{
                        document.getElementById('bet-form').submit();
                    }
                }
            })
        }
    
    }
    function formatAMPM(date) {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0'+minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return strTime;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/frontend/bets/show-body.blade.php ENDPATH**/ ?>