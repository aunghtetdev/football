<?php $__env->startSection('display','d-none d-md-block'); ?>

<?php $__env->startSection('content'); ?>
<div class="web-sidebar-widget">
    <div class="widget-head">
        <div class="d-flex justify-content-between">
            <h3>အကောင့် password ပြောင်းရန်</h3>
        </div>
    </div>
    <div class="widget-body">
        <form action="<?php echo e(route('change_password')); ?>" method="POST" id="change-password">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="">Old Password</label>
                <input type="text" class="form-control" name="old_password">
            </div>

            <div class="form-group">
                <label for="">New Password</label>
                <input type="text" class="form-control" name="new_password">
            </div>
            <button type="submit" class="btn btn-light btn-sm mt-3">Confirm</button>
        </form>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\ChangePassword', '#change-password'); ?>

    <script>

        $(document).ready(function(){

        })
        
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/frontend/profile/index.blade.php ENDPATH**/ ?>