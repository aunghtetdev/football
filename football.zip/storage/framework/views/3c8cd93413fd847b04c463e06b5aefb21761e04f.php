<?php $__env->startSection('title', 'Previous Bet'); ?>
<?php echo $__env->make('frontend.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('display','d-none d-md-block'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-3 col-md-6 col-lg-8">
                <span class="mb-1" style="font-weight: 900 ">ပွဲစဥ်ဟောင်းများ</span>
            </div>
            <div class="col-9 col-md-6 col-lg-4 ">
                <form action="<?php echo e(route('match.filter-previous-bet')); ?>" method="post" id="filter-form" class="mb-0">
                    <?php echo csrf_field(); ?>
                    <p class="mb-1">Date: <input type="text" autocomplete="off" id="datepicker" name="date" >
                    </p>  
                </form>
            </div>
        </div>
    </div>
    
    <?php echo $__env->make('frontend.bets.bet-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$( function() {
    $( "#datepicker" ).datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function(date) {
            $("#filter-form").submit();
            //OR $("#yourButton").click();
        }
    });
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/frontend/bets/previous-bet.blade.php ENDPATH**/ ?>