 <!-- Main Sidebar Container -->
 <aside class="main-sidebar sidebar-dark-primary elevation-4" >
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/admin/home')); ?>" class="brand-link">
    <img src="<?php echo e(asset('image/football.png')); ?>" alt="lara Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">Football</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
        <img src="<?php echo e(asset('image/programmer.png')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
        <a href="#" class="d-block"><?php echo e(Auth::guard('admin')->user()->username); ?></a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
            with font-awesome or any other icon font library -->
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/dashboard')); ?>" class="nav-link  <?php echo $__env->yieldContent('dashboard'); ?>" >
            <i class="nav-icon fas fa-gauge"></i>
            <p>Dashboard</p>
            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/home')); ?>" class="nav-link  <?php echo $__env->yieldContent('admin'); ?>" >
            <i class="nav-icon  fas fa-user"></i>
            <p>Admin</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role')): ?>
            <li class="nav-item ">
                <a href="<?php echo e(url('/admin/roles')); ?>" class="nav-link <?php echo $__env->yieldContent('role'); ?>" >
                <i class="nav-icon  fab fa-shirtsinbulk"></i>
                <p>Role</p>
                </a>
            </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/permissions')); ?>" class="nav-link <?php echo $__env->yieldContent('permission'); ?>" >
            <i class="nav-icon  fas fa-user-lock"></i>
            <p>Permission</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/users')); ?>" class="nav-link <?php echo $__env->yieldContent('user'); ?>" >
            <i class="nav-icon  fas fa-user"></i>
            <p>User</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('league')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/leagues')); ?>" class="nav-link <?php echo $__env->yieldContent('league'); ?>" >
            <i class="nav-icon text-light fas fa-futbol"></i>
            <p>League</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('team')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/teams')); ?>" class="nav-link <?php echo $__env->yieldContent('team'); ?>" >
            <i class="nav-icon text-light fas fa-toolbox"></i>
            <p>Team</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('match')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/matches')); ?>" class="nav-link <?php echo $__env->yieldContent('match'); ?>" >
            <i class="nav-icon text-white fas fa-futbol"></i>
            <p>Match</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('odds')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/odds')); ?>" class="nav-link <?php echo $__env->yieldContent('odds'); ?>" >
            <i class="nav-icon text-white fas fa-money-bill-alt"></i>
            <p>Odds</p>
            </a>
        </li>
        <?php endif; ?>


        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('balance')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/wallets')); ?>" class="nav-link <?php echo $__env->yieldContent('wallet'); ?>" >
            <i class="nav-icon text-light fas fa-wallet"></i>
            <p>Balance</p>
            </a>
        </li>
        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('balance')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/wallets/history')); ?>" class="nav-link <?php echo $__env->yieldContent('history'); ?>" >
            <i class="nav-icon text-light fas fa-history"></i>
            <p>Balance History</p>
            </a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bet')): ?>
        <li class="nav-item">
            <a href="<?php echo e(url('/admin/bets')); ?>" class="nav-link <?php echo $__env->yieldContent('bet'); ?>" >
            <i class="nav-icon text-light fas fa-dollar-sign"></i>
            <p>Bet</p>
            </a>
        </li>
        <?php endif; ?>

        <li class="nav-item">
            <a href="<?php echo e(url('/feedbacks')); ?>" class="nav-link <?php echo $__env->yieldContent('feedback'); ?>" >
            <i class="nav-icon text-light fas fa-comment"></i>
            <p>Feedback</p>
            </a>
        </li>
        
        <li class="nav-item">
            <a class="nav-link" href="#"
                onclick="
                event.preventDefault();
                if(confirm('Are you sure you want to logout?'))
                document.getElementById('logout-form').submit();
                ">
                <p> <i class="nav-icon text-danger fas fa-power-off"></i> Logout</p>
            </a>

            <form id="logout-form" action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </li>

        
        </ul>
    </nav>
    <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside><?php /**PATH /home/dell/D/football/resources/views/backend/layouts/side.blade.php ENDPATH**/ ?>