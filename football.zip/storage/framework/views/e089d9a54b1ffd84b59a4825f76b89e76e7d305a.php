<?php $__env->startSection('odds','active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container pt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <a href="<?php echo e(url('admin/odds')); ?>"><span class="badge badge-theme p-2"><i class="fas fa-arrow-left"></i></span></a>
                    Odds Edit Page
                </div>
                <form action="<?php echo e(route('odds.update',$odds->id)); ?>" method="POST" id="match-edit">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <div class="label">Matches</div>
                            <input type="hidden" value="<?php echo e($matches['id']); ?>" name="match_id">
                            <select name="match_id" class="form-control" id="get_team" disabled>
                                <option value="<?php echo e($matches['id']); ?>"><?php echo e($matches['match_name']); ?></option>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="label">Over Team</div>
                                    <input type="hidden" value="<?php echo e($odds->over_team_id); ?>" name="over_team_id">
                                    <select name="over_team_id" class="form-control" disabled>
                                        <option value="<?php echo e($odds->over_team_id); ?>"><?php echo e($odds->over_team_name); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="label">Under Team</div>
                                    <input type="hidden" value="<?php echo e($odds->underteam_id); ?>" name="underteam_id">
                                    <select name="underteam_id" class="form-control" id="under_team" disabled>
                                        <option value="<?php echo e($odds->underteam_id); ?>"><?php echo e($odds->under_team_name); ?></option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="label">Body</div>
                                    <input type="text" class="form-control" value="<?php echo e($odds->body_value); ?>" name="body_value">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="label">Goal Total</div>
                                    <input type="text" class="form-control" value="<?php echo e($odds->goal_total_value); ?>" name="goal_total_value">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-theme" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\OddsUpdate', '#match-edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/backend/odds/edit.blade.php ENDPATH**/ ?>