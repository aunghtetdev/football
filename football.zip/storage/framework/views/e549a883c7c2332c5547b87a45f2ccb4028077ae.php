<?php $__env->startSection('permission','active'); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('backend.layouts.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container pt-3">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Permission Edit Page
                </div>
                <form action="<?php echo e(route('permissions.update',$permission->id)); ?>" method="POST" id="permission-edit">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" class="form-control" name="name" value="<?php echo e($permission->name); ?>">
                        </div>

                      
                    </div>
                    <div class="card-footer">
                        <button class="btn btn-theme" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\PermissionEdit', '#permission-edit'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/D/football/resources/views/backend/permissions/edit.blade.php ENDPATH**/ ?>